-- 会员卡操作记录表
CREATE TABLE IF NOT EXISTS `card_operations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `card_id` bigint NOT NULL COMMENT '会员卡ID',
  `operation_type` tinyint NOT NULL COMMENT '操作类型: 1-续费, 2-冻结, 3-解冻, 4-转卡, 5-退卡',
  `operator_id` bigint NOT NULL COMMENT '操作员ID',
  `amount` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `old_end_date` date DEFAULT NULL COMMENT '原到期日期',
  `new_end_date` date DEFAULT NULL COMMENT '新到期日期',
  `freeze_days` int DEFAULT NULL COMMENT '冻结天数',
  `transfer_to_id` bigint DEFAULT NULL COMMENT '转卡目标用户ID',
  `remark` text COMMENT '备注',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_card_id` (`card_id`),
  KEY `idx_operation_type` (`operation_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员卡操作记录表';
