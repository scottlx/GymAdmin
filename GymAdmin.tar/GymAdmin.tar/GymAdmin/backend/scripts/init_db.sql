-- Create database
CREATE DATABASE IF NOT EXISTS gym_admin CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE gym_admin;

-- Note: Tables will be auto-created by GORM AutoMigrate
-- This script is just for creating the database

-- Optional: Create a test user for development
-- Password should be hashed in production
-- INSERT INTO users (user_no, name, phone, gender, status, created_at, updated_at) 
-- VALUES ('U001', 'Test User', '13800138000', 1, 1, NOW(), NOW());
