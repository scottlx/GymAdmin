-- Create user_status_logs table
CREATE TABLE IF NOT EXISTS user_status_logs (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL,
    old_status TINYINT NOT NULL COMMENT '1-正常，2-冻结，3-黑名单',
    new_status TINYINT NOT NULL COMMENT '1-正常，2-冻结，3-黑名单',
    reason TEXT,
    operator_id BIGINT COMMENT '操作人ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_operator_id (operator_id),
    INDEX idx_deleted_at (deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户状态变更日志表';
